#include "stdafx.h"

// Temp storage
char buffer[4096] = {0};

// -------------------------------------------------------------------------------
// COMMANDS
// -------------------------------------------------------------------------------
bool OllyLang::DoADD(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD dw1, dw2;
	string str1, str2;
	if(GetDWOpValue(ops[0], dw1) && GetDWOpValue(ops[1], dw2))
	{
		args = ops[0] + ", " + ultoa(dw1 + dw2, buffer, 16);
		return DoMOV(args);
	}
	else if(GetSTROpValue(ops[0], str1) && GetANYOpValue(ops[1], str2, false))
	{
		args = ops[0] + ", " + "\"" + str1 + str2 + "\"";
		return DoMOV(args);
	}
	return false;
}

bool OllyLang::DoAI(string args)
{
	Sendshortcut(PM_MAIN, 0, WM_KEYDOWN, 1, 0, VK_F7); 
	require_ollyloop = 1;
	return true;
}

bool OllyLang::DoAN(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	DWORD dw;
	if(GetDWOpValue(ops[0], dw))
	{
		Analysecode(Findmodule(dw));
		require_ollyloop = 1;
		return true;
	}
	return false;
}

bool OllyLang::DoAND(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD dw1, dw2;
	if(GetDWOpValue(ops[0], dw1) && GetDWOpValue(ops[1], dw2))
	{
		args = ops[0] + ", " + ultoa(dw1 & dw2, buffer, 16);
		return DoMOV(args);
	}
	return false;
}

bool OllyLang::DoAO(string args)
{
	Sendshortcut(PM_MAIN, 0, WM_KEYDOWN, 1, 0, VK_F8); 
	require_ollyloop = 1;
	return true;
}

bool OllyLang::DoASK(string args)
{
	string ops[1];
	string title;

	if(!CreateOperands(args, ops, 1))
		return false;

	if(GetSTROpValue(ops[0], title))
	{
		HINSTANCE hi = (HINSTANCE)GetModuleHandle("ODbgScript.dll");
		HWND hw = (HWND)Plugingetvalue(VAL_HWMAIN);
		char* returned_buffer = (char*)DialogBoxParam(hi, MAKEINTRESOURCE(IDD_INPUT), hw, (DLGPROC) InputDialogProc, (LPARAM)title.c_str());
		if((int)returned_buffer != 0)
		{
			string returned = returned_buffer;
			if(is_hex(returned))
				variables["$RESULT"] = strtoul(returned.c_str(), 0, 16);
			else
				variables["$RESULT"] = returned.c_str();
		}
		else
		{
			variables["$RESULT"] = 0;
		}
		return true;
	}

	return false;
}

bool OllyLang::DoASM(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	t_asmmodel model;
	DWORD addr;
	string cmd;
	char error[255] = {0};
	int len = 0;

	if(GetDWOpValue(ops[0], addr) && GetSTROpValue(ops[1], cmd))
	{
		strcpy(buffer, cmd.c_str());
		if((len = Assemble(buffer, addr, &model, 0, 0, error)) < 0)
		{
			errorstr = error;
			return false;
		}
		else
		{
			Writememory(model.code, addr, len, MM_DELANAL | MM_SILENT);
			Broadcast(WM_USER_CHALL, 0, 0);
			variables["$RESULT"] = len;
			require_ollyloop = 1;
			return true;
		}
	}

	return false;
}

bool OllyLang::DoBC(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	DWORD dw;
	if(GetDWOpValue(ops[0], dw))
	{
		Deletebreakpoints(dw, dw + 1, 0);
		Broadcast(WM_USER_CHALL, 0, 0);
		require_ollyloop = 1;
		return true;
	}
	return false;
}

bool OllyLang::DoBP(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	DWORD dw;
	if(GetDWOpValue(ops[0], dw))
	{
		Setbreakpoint(dw, TY_ACTIVE, 0);
		Broadcast(WM_USER_CHALL, 0, 0);
		require_ollyloop = 1;
		return true;
	}
	return false;
}

bool OllyLang::DoBPCND(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD addr = 0;
	string condition;
	if(GetDWOpValue(ops[0], addr) && GetSTROpValue(ops[1], condition))
	{
		char* buffer = new char[condition.length() + 1];
		strcpy(buffer, condition.c_str());
		Setbreakpoint(addr, TY_ACTIVE, 0);
		Insertname(addr, NM_BREAK, buffer);
		Deletenamerange(addr, addr + 1, NM_BREAKEXPL);
		Deletenamerange(addr, addr + 1, NM_BREAKEXPR);
		Broadcast(WM_USER_CHALL,0,0);
		delete buffer;
		return true;
	}
	return false;
}

bool OllyLang::DoBPHWC(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	DWORD dw1;
	if(GetDWOpValue(ops[0], dw1))
	{
		Deletehardwarebreakbyaddr(dw1);
		require_ollyloop = 1;
		return true;
	}
	return false;
}

bool OllyLang::DoBPHWS(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD dw1;
	string str1;
	if(GetDWOpValue(ops[0], dw1) && GetSTROpValue(ops[1], str1))
	{
		int type;
		if(str1 == "r")
			type = HB_ACCESS;
		else if(str1 == "w")
			type = HB_WRITE;
		else if(str1 == "x")
			type = HB_CODE;
		else
			return false;

		Sethardwarebreakpoint(dw1, 1, type);
		require_ollyloop = 1;
		return true;
	}
	return false;
}

bool OllyLang::DoBPL(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD addr = 0;
	string expression;
	if(GetDWOpValue(ops[0], addr) && GetSTROpValue(ops[1], expression))
	{
		wsprintf(buffer, "%c%s", 0x45/*COND_NOBREAK | COND_LOGALWAYS | COND_ARGALWAYS | COND_FILLING*/, expression.c_str());
		Setbreakpoint(addr, TY_ACTIVE, 0);
		Deletenamerange(addr, addr + 1, NM_BREAK);
		Deletenamerange(addr, addr + 1, NM_BREAKEXPL);
		Insertname(addr, NM_BREAKEXPR, buffer);
		Broadcast(WM_USER_CHALL,0,0);
		return true;
	}
	return false;
}

bool OllyLang::DoBPLCND(string args)
{
	string ops[3];

	if(!CreateOperands(args, ops, 3))
		return false;

	DWORD addr = 0;
	string expression, condition;
	if(GetDWOpValue(ops[0], addr) && GetSTROpValue(ops[1], expression) && GetSTROpValue(ops[2], condition))
	{
		Setbreakpoint(addr, TY_ACTIVE, 0);
		Deletenamerange(addr, addr + 1, NM_BREAKEXPL);
		wsprintf(buffer, "%s", condition.c_str());
		Insertname(addr, NM_BREAK, buffer);
		wsprintf(buffer, "%c%s", 0x43, expression.c_str());
		Insertname(addr, NM_BREAKEXPR, buffer);
		Broadcast(WM_USER_CHALL,0,0);
		return true;
	}
	return false;
}

bool OllyLang::DoBPMC(string args)
{
	Setmembreakpoint(0, 0, 0);
	return true;
}

bool OllyLang::DoBPRM(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD addr, size;
	if(GetDWOpValue(ops[0], addr) && GetDWOpValue(ops[1], size))
	{
		Setmembreakpoint(MEMBP_READ, addr, size);
		return true;
	}
	return false;
}

bool OllyLang::DoBPWM(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD addr, size;
	if(GetDWOpValue(ops[0], addr) && GetDWOpValue(ops[1], size))
	{
		Setmembreakpoint(MEMBP_READ | MEMBP_WRITE, addr, size);
		return true;
	}
	return false;
}

bool OllyLang::DoCMP(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD dw1 = 0, dw2 = 0;
	string s1, s2;
	if(GetDWOpValue(ops[0], dw1) && GetDWOpValue(ops[1], dw2))
	{
		if(dw1 > dw2)
		{
			zf = 0;
			cf = 0;
		}
		else if(dw1 < dw2)
		{
			zf = 0;
			cf = 1;
		}
		else
		{
			zf = 1;
			cf = 0;
		}
/*		this->DoLOG(args);
		char * pArgs = new char[args.length()+1];
		strcpy(pArgs,args.c_str());
		MessageBox(hwmain,pArgs,"",MB_OK|MB_ICONEXCLAMATION);
		delete[] pArgs;*/
		return true;
	}
	else if(GetANYOpValue(ops[0], s1, false) && GetANYOpValue(ops[1], s2, false))
	{
		int res = s1.compare(s2);
		if(res > 0)
		{
			zf = 0;
			cf = 0;
		}
		else if(res < 0)
		{
			zf = 0;
			cf = 1;
		}
		else
		{
			zf = 1;
			cf = 0;
		}
		return true;
	}
	return false;
}

bool OllyLang::DoCMT(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	string cmt;
	DWORD addr;

	if(GetDWOpValue(ops[0], addr) && GetSTROpValue(ops[1], cmt))
	{
		if(cmt != "")
		{
			strcpy(buffer, cmt.c_str());
			Insertname(addr, NM_COMMENT, buffer);
			Broadcast(WM_USER_CHALL, 0, 0);
		}
		else
		{
			Deletenamerange(addr, addr + 1, NM_COMMENT);
			Broadcast(WM_USER_CHALL, 0, 0);
		}
		return true;
	}
	return false;
}

bool OllyLang::DoCOB(string args)
{
	EOB_row = -1;
	return true;
}

bool OllyLang::DoCOE(string args)
{
	EOE_row = -1;
	return true;
}

bool OllyLang::DoDBH(string args)
{
	t_thread* thr = Findthread(Getcputhreadid());
	byte buffer[4];
	ulong fs = thr->reg.limit[2]; // BUG IN ODBG!!!
	fs += 0x30;
	Readmemory(buffer, fs, 4, MM_RESTORE);
	fs = *((ulong*)buffer);
	fs += 2;
	buffer[0] = 0;
	Writememory(buffer, fs, 1, MM_RESTORE);
	return true;   
}

bool OllyLang::DoDBS(string args)
{
	t_thread* thr = Findthread(Getcputhreadid());
	byte buffer[4];
	ulong fs = thr->reg.limit[2]; // BUG IN ODBG!!!
	fs += 0x30;
	Readmemory(buffer, fs, 4, MM_RESTORE);
	fs = *((ulong*)buffer);
	fs += 2;
	buffer[0] = 1;
	Writememory(buffer, fs, 1, MM_RESTORE);
	return true;   
}

bool OllyLang::DoDEC(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	return DoSUB(ops[0] + ", 1");
}

bool OllyLang::DoDM(string args)
{
	string ops[3];
	if(!CreateOperands(args, ops, 3))
		return false;
	
	DWORD addr, size;
	string filename;
	if(GetDWOpValue(ops[0], addr) && GetDWOpValue(ops[1], size) && GetSTROpValue(ops[2], filename))
	{
		char* membuf = new char[size];
		int memlen = Readmemory(membuf, addr, size, MM_RESILENT);

		ofstream fout;
		fout.open(filename.c_str());
		if(!fout.fail())
		{
			for(int i = 0; i < size; i++)
				fout << membuf[i];
			fout.close();
			delete [] membuf;
			return true;
		}
		else
		{
			errorstr = "Couldn't create file!";
			delete [] membuf;
			return false;
		}
	}
	return false;
}

bool OllyLang::DoDMA(string args)
{
	string ops[3];
	if(!CreateOperands(args, ops, 3))
		return false;

	DWORD addr, size;
	string filename;
	if(GetDWOpValue(ops[0], addr) && GetDWOpValue(ops[1], size) && GetSTROpValue(ops[2], filename))
	{
		char* membuf = new char[size];
		int memlen = Readmemory(membuf, addr, size, MM_RESILENT);

		ofstream fout;
		fout.open(filename.c_str(), ios::app);
		if(!fout.fail())
		{
			for(int i = 0; i < size; i++)
				fout << membuf[i];
			fout.close();
			delete [] membuf;
			return true;
		}
		else
		{
			errorstr = "Couldn't create file!";
			delete [] membuf;
			return false;
		}
	}
	return false;
}

bool OllyLang::DoDPE(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	string filename;
	DWORD ep;
	if(GetSTROpValue(ops[0], filename) && GetDWOpValue(ops[1], ep))
	{
		bool result = false;
		result = GetPEInfo(ep);
		if (!result)
			return result;
		result = SaveDump(filename, ep);
		return result;
	}
	return false;
}

bool OllyLang::DoENDE(string args)
{
	// Free memory
	HANDLE hDebugee = (HANDLE)Plugingetvalue(VAL_HPROCESS);
	VirtualFreeEx(hDebugee, pmemforexec, 0, MEM_RELEASE);
	return true;
}

bool OllyLang::DoESTI(string args)
{
	Sendshortcut(PM_MAIN, 0, WM_KEYDOWN, 0, 1, VK_F7); 
	require_ollyloop = 1;
	return true;
}

bool OllyLang::DoESTO(string args)
{
	Sendshortcut(PM_MAIN, 0, WM_KEYDOWN, 0, 1, VK_F9); 
	require_ollyloop = 1;
	return true;
}

bool OllyLang::DoEOB(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	if(ops[0] == "") // Go interactive
		EOB_row = -1;
	else if(labels.find(ops[0]) != labels.end()) // Set label to go to
		EOB_row = labels[ops[0]];
	else
		return false;
	return true;
}

bool OllyLang::DoEOE(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	if(ops[0] == "") // Go interactive
		EOE_row = -1;
	else if(labels.find(ops[0]) != labels.end()) // Set label to go to
		EOE_row = labels[ops[0]];
	else
		return false;
	return true;
}

bool OllyLang::DoEVAL(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	string to_eval;

	if(GetSTROpValue(ops[0], to_eval))
	{
		string res = ResolveVarsForExec(to_eval);
		variables["$RESULT"] = res;
		return true;
	}
	return false;
}

bool OllyLang::DoEXEC(string args)
{
	// Old eip
	ulong eip;
	// For Assemble API
	t_asmmodel model;
	char error[255] = {0};
	char buffer[255] = {0};
	// Bytes assembled
	int len = 0, totallen = 0;
	// Temp storage
	string tmp;

	// Get process handle and save eip
	HANDLE hDebugee = (HANDLE)Plugingetvalue(VAL_HPROCESS);
	t_thread* thr = Findthread(Getcputhreadid());
	eip = thr->reg.ip;

	// Allocate memory for code
	pmemforexec = VirtualAllocEx(hDebugee, NULL, 0x1000, MEM_COMMIT, PAGE_EXECUTE_READWRITE);

	// Pass EXECs
	script_pos++;

	// Assemble and write code to memory (everything between EXEC and ENDE)
	while(ToLower(script[script_pos]) != "ende")
	{
		tmp = ResolveVarsForExec(script[script_pos]);
		wsprintf(buffer, tmp.c_str());
		len = Assemble(buffer, (ulong)pmemforexec + totallen, &model, 0, 0, error);
		WriteProcessMemory(hDebugee, (LPVOID)((ulong)pmemforexec + totallen), model.code, len, 0);
		totallen += len;
		script_pos++;
	}

	// Assemble and write jump to original EIP
	wsprintf(buffer, "JMP %lX", eip);
	len = Assemble(buffer, (ulong)pmemforexec + totallen, &model, 0, 0, error);
	WriteProcessMemory(hDebugee, (LPVOID)((ulong)pmemforexec + totallen), model.code, len, 0);

	// Set new eip and run to the original one
	thr->reg.ip = (ulong)pmemforexec;
	thr->reg.modified = 1;
	thr->regvalid = 1;
	Broadcast(WM_USER_CHREG, 0, 0);
	Go(Getcputhreadid(), eip, STEP_RUN, 0, 1);
	return true;
}

bool OllyLang::DoFILL(string args)
{
	string ops[3];

	if(!CreateOperands(args, ops, 3))
		return false;
	DWORD start, len, val;

	if(GetDWOpValue(ops[0], start) && GetDWOpValue(ops[1], len) && GetDWOpValue(ops[2], val))
	{
		byte* buffer = new byte[len];
		byte b = 0 + val;
		for(ulong i = 0; i < len; i++)
			buffer[i] = b;
		Writememory(buffer, start, len, MM_DELANAL | MM_SILENT);
		delete [] buffer;
		Broadcast(WM_USER_CHALL, 0, 0);
		require_ollyloop = 1;
		return true;
	}

	return false;
}

bool OllyLang::DoFIND(string args)
{
	string ops[2];
	if(!CreateOperands(args, ops, 2))
		return false;

	if(ops[1].length() % 2 != 0)
	{
		errorstr = "Hex string must have an even number of characters!";
		return false;
	}

	DWORD addr;
	if(GetDWOpValue(ops[0], addr) && UnquoteString(ops[1], '#', '#'))
	{
		if(ops[1].find('?') != -1)
		{
			// Wildcard search
			char *membuf = 0;
			t_memory* tmem = Findmemory(addr);
			int memlen = tmem->size - (addr - tmem->base);
			membuf = new char[memlen];

			memlen = Readmemory(membuf, addr, memlen, MM_RESILENT);
			int pos = FindWithWildcards(membuf, ops[1].c_str(), memlen);

			delete [] membuf;

			if(pos > -1)
				variables["$RESULT"] = addr + pos;
			else
				variables["$RESULT"] = 0;
		}
		else
		{
			// Regular search
			char *membuf = 0;
			t_memory* tmem = Findmemory(addr);
			int memlen = tmem->size - (addr - tmem->base);
			membuf = new char[memlen];

			int len = Str2Rgch(ops[1], buffer, sizeof(buffer));

			memlen = Readmemory(membuf, addr, memlen, MM_RESILENT);
			char* p = search(membuf, membuf + memlen, buffer, buffer + len);

			delete [] membuf;

			if(p < membuf + memlen)
				variables["$RESULT"] = addr + p - membuf;
			else
				variables["$RESULT"] = 0;
		}
		return true;
	}
	return false;
}

bool OllyLang::DoFINDOP(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	if(ops[1].length() % 2 != 0)
	{
		errorstr = "Hex string must have an even number of characters!";
		return false;
	}

	DWORD addr, endaddr;
	int result = -1;
	int ok = 0;
	if(GetDWOpValue(ops[0], addr) && UnquoteString(ops[1], '#', '#'))
	{
		t_memory* tmem = Findmemory(addr);
		char cmd[MAXCMDSIZE] = {0};
		do 
		{
			addr = Disassembleforward(0, tmem->base, tmem->size, addr, 1, 0); 
			endaddr = Disassembleforward(0, tmem->base, tmem->size, addr, 1, 0); 
			ok = Readcommand(addr, cmd);

			if(addr == tmem->base + tmem->size)
				ok = 0;

			if(ok)
				result = FindWithWildcards(cmd, ops[1].c_str(), endaddr - addr);
		} while(result != 0 && ok != 0);
	}
	if(ok != 0)
		variables["$RESULT"] = addr;
	else
		variables["$RESULT"] = 0;
	return true;
}

bool OllyLang::DoGMI(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD addr = 0;

	if(GetDWOpValue(ops[0], addr) && find_if(ops[1].begin(), ops[1].end(), not1(ptr_fun(isalpha))) == ops[1].end())
	{
		t_module* mod = Findmodule(addr);
		if(ops[1] == "MODULEBASE" && mod != NULL)
		{
			variables["$RESULT"] = (DWORD)mod->base;
			return true;
		}
		else if(ops[1] == "MODULESIZE" && mod != NULL)
		{
			variables["$RESULT"] = (DWORD)mod->size;
			return true;
		}
		else if(ops[1] == "CODEBASE" && mod != NULL)
		{
			variables["$RESULT"] = (DWORD)mod->codebase;
			return true;
		}
		else if(ops[1] == "CODESIZE" && mod != NULL)
		{
			variables["$RESULT"] = (DWORD)mod->origcodesize;
			return true;
		}
		else if(mod == NULL)
		{
			variables["$RESULT"] = 0;
			return true;
		}
		else
		{
			variables["$RESULT"] = 0;
			errorstr = "Second operand bad";
			return false;
		}
	}

	errorstr = "Bad operand";
	return false;
}

bool OllyLang::DoGN(string args)
{
	string ops[1];
	DWORD addr;

	if(!CreateOperands(args, ops, 1))
		return false;

	if(GetDWOpValue(ops[0], addr))
	{
		char sym[4096] = {0};
		char buf[TEXTLEN] = {0};
		int res = Decodeaddress(addr, 0, ADC_JUMP | ADC_STRING | ADC_ENTRY | ADC_OFFSET | ADC_SYMBOL, sym, 4096, buf);
		if(res)
		{
			variables["$RESULT"] = sym;
			char* tmp = strstr(sym, ".");
			if(tmp)
			{
				*tmp = '\0';
				variables["$RESULT_1"] = sym;
				variables["$RESULT_2"] = tmp + 1;
			}
		}
		else
		{
			variables["$RESULT"] = 0;
			variables["$RESULT_1"] = 0;
			variables["$RESULT_2"] = 0;
		}

		return true;
	}

	return false;
}

bool OllyLang::DoGO(string args)
{
	string ops[1];
	DWORD addr;

	if(!CreateOperands(args, ops, 1))
		return false;

	if(GetDWOpValue(ops[0], addr))
	{
		Go(Getcputhreadid(), addr, STEP_RUN, 1, 1);
		require_ollyloop = 1;
      return true;
	}

	return false;
}

bool OllyLang::DoGPA(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	string proc, lib;

	if(GetSTROpValue(ops[0], proc) && GetSTROpValue(ops[1], lib))
	{
		HMODULE hMod = LoadLibrary(lib.c_str());
		if(hMod == 0)
		{
			errorstr = "No such library: " + lib;
			variables["$RESULT"] = 0;
			return false;
		}

		FARPROC p = GetProcAddress(hMod, proc.c_str());
		if(p == 0)
		{
			errorstr = "No such procedure: " + proc;
			variables["$RESULT"] = 0;
			return false;
		}

		variables["$RESULT"] = (DWORD) p;
		FreeLibrary(hMod);
		return true;
	}

	variables["$RESULT"] = 0;
	return false;
}

bool OllyLang::DoINC(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	return DoADD(ops[0] + ", 1");
}

bool OllyLang::DoJA(string args)
{
	if(zf == 0 && cf == 0)
		return DoJMP(args);
	return true;
}

bool OllyLang::DoJAE(string args)
{
	if(cf == 0)
		return DoJMP(args);
	return true;
}

bool OllyLang::DoJB(string args)
{
	if(cf == 1)
		return DoJMP(args);
	return true;
}

bool OllyLang::DoJBE(string args)
{
	if(zf == 1 || cf == 1)
		return DoJMP(args);
	return true;
}

bool OllyLang::DoJE(string args)
{
	if(zf == 1)
		return DoJMP(args);
	return true;
}

bool OllyLang::DoJMP(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	if(labels.find(ops[0]) == labels.end())
		return false;

	script_pos = labels[ops[0]] - 1;
	return true;
}

bool OllyLang::DoJNE(string args)
{
	if(zf == 0)
		return DoJMP(args);
	return true;
}

bool OllyLang::DoLBL(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	string lbl;
	DWORD addr;

	if(GetDWOpValue(ops[0], addr) && GetSTROpValue(ops[1], lbl))
	{
		if(lbl != "")
		{
			strcpy(buffer, lbl.c_str());
			Insertname(addr, NM_LABEL, buffer);
			Broadcast(WM_USER_CHALL, 0, 0);
		}
		else
		{
			Deletenamerange(addr, addr + 1, NM_COMMENT);
			Broadcast(WM_USER_CHALL, 0, 0);
		}
		return true;
	}
	return false;
}

bool OllyLang::DoLOG(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	DWORD dw = 0;
	string str;

	if(UnquoteString(ops[0], '"', '"'))
	{
		strcpy(buffer, ops[0].c_str());
		Addtolist(0, -1, buffer);
		return true;
	}
	else if(GetDWOpValue(ops[0], dw))
	{
		char sym[4096] = {0};
		char buf[TEXTLEN] = {0};
		int res = Decodeaddress(dw, 0, ADC_JUMP | ADC_STRING | ADC_ENTRY | ADC_OFFSET | ADC_SYMBOL, sym, 4096, buf);
		sprintf(buffer, "%s = %08lX", ops[0].c_str(), dw);

		if(strcmp(buf, ""))
			sprintf(buffer, "%s | %s", buffer, buf);

		if(strcmp(sym, "") && dw !=  strtoul(sym, 0, 16))
			sprintf(buffer, "%s | %s", buffer, sym);

		Addtolist(0, -1, buffer);
		return true;
	}
	else if(GetSTROpValue(ops[0], str))
	{
		sprintf(buffer, "%s = %s", ops[0].c_str(), variables[ops[0]].str.c_str());
		Addtolist(0, -1, buffer);
		return true;
	}
	return false;
}

bool OllyLang::DoMOV(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	// Check source
	DWORD dw = 0, addr = 0;
	string str = "";

	// Check destination
	if(variables.find(ops[0]) != variables.end())
	{
		// Dest is variable
		if(GetDWOpValue(ops[1], dw))
		{
			variables[ops[0]].vt = DW;
			variables[ops[0]] = dw;
		}
		else if(GetSTROpValue(ops[1], str))
		{
			variables[ops[0]].vt = STR;
			variables[ops[0]] = str;
		}
		else 
			return false;
		return true;
	}
	else if(is_register(ops[0]))
	{
		// Dest is register
		if(GetDWOpValue(ops[1], dw))
		{
			t_thread* pt = Findthread(Getcputhreadid());
			int regnr = GetRegNr(ops[0]);

			if(regnr != -1) {

				pt->reg.r[regnr] = dw;

			} else if(ops[0] == "eip") {

					pt->reg.ip = dw;

			} else {

				// 16/8bit register
				struct p_reg32 *r_32;
				DWORD cur_val;
				char fmt_buf[1024];

				// Locate the 32bit reg & it's value				
				regnr = GetRegNr(o_32regs[ops[0]]);
				cur_val = pt->reg.r[regnr];
				
				// Unpack the 32bit reg
				r_32 = (struct p_reg32 *)&cur_val;

				// Is it a 16bit reg?
				if (ops[0][1] == 'x' || ops[0][1] == 'i') {

					r_32->l_word.l_byte = dw & 0x000000FF;
					r_32->l_word.u_byte = dw & 0x0000FF00;
				}
				
				// Is it a 8bit reg? (LOWER)
				if (ops[0][1] == 'l') {

					r_32->l_word.l_byte = dw & 0x000000FF;
				}
				
				// Is it a 8bit reg? (UPPER)
				if (ops[0][1] == 'h') {

					r_32->l_word.u_byte = dw & 0x000000FF;
				}

				// Overwrite 32bit register after modification
				pt->reg.r[regnr] = cur_val;

			}

			pt->reg.modified = 1;
			pt->regvalid = 1;
			Broadcast(WM_USER_CHREG, 0, 0);
			require_ollyloop = 1;
			return true;
		}
		return false;
	}
	else if(is_flag(ops[0]))
	{
		// Dest is flag
		if(GetDWOpValue(ops[1], dw))
		{
			if(dw != 0 && dw != 1)
			{
				errorstr = "Invalid flag value";
				return false;
			}

			eflags flags;
			ZeroMemory(&flags, sizeof DWORD);
			t_thread* pt = Findthread(Getcputhreadid());
			flags.dwFlags = pt->reg.flags;

			if(stricmp(ops[0].c_str(), "!af") == 0)
				flags.bitFlags.AF = dw;
			else if(stricmp(ops[0].c_str(), "!cf") == 0)
				flags.bitFlags.CF = dw;
			else if(stricmp(ops[0].c_str(), "!df") == 0)
				flags.bitFlags.DF = dw;
			else if(stricmp(ops[0].c_str(), "!of") == 0)
				flags.bitFlags.OF = dw;
			else if(stricmp(ops[0].c_str(), "!pf") == 0)
				flags.bitFlags.PF = dw;
			else if(stricmp(ops[0].c_str(), "!sf") == 0)
				flags.bitFlags.SF = dw;
			else if(stricmp(ops[0].c_str(), "!zf") == 0)
				flags.bitFlags.ZF = dw;

			pt->reg.flags = flags.dwFlags;
			pt->reg.modified = 1;
			pt->regvalid = 1;
			Broadcast(WM_USER_CHREG, 0, 0);
			require_ollyloop = 1;
			return true;
		}
		return false;
	}
	else if(UnquoteString(ops[0], '[', ']'))
	{
		// Dest is memory address
		if(GetDWOpValue(ops[0], addr))
		{
			if(GetDWOpValue(ops[1], dw))
			{
				Writememory(&dw, addr, 4, MM_DELANAL | MM_SILENT);
			}
			else if(ops[1].length() % 2 == 0 && UnquoteString(ops[1], '#', '#'))
			{
				int len = Str2Rgch(ops[1], buffer, sizeof(buffer));
				Writememory(buffer, addr, len, MM_DELANAL | MM_SILENT);
				Broadcast(WM_USER_CHALL, 0, 0);
			}
			else if(GetSTROpValue(ops[1], str))
			{
				strcpy(buffer, str.c_str());
				Writememory(buffer, addr, str.length(), MM_DELANAL | MM_SILENT);
				Broadcast(WM_USER_CHALL, 0, 0);
			}
			else
			{
				errorstr = "Bad operator \"" + ops[1] + "\"";
				return false;
			}
			Broadcast(WM_USER_CHMEM, 0, 0);
			return true;
		}
		return false;
	}

	errorstr = "Variable '" + ops[0] + "' is not declared";
	return false;
}

bool OllyLang::DoMSG(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	string msg;
	if(GetANYOpValue(ops[0], msg, false))
	{
		MessageBox(hwmain, msg.c_str(), "OllyScript", MB_ICONINFORMATION | MB_OK | MB_TOPMOST);
		return true;
	}
	return false;
}

bool OllyLang::DoMSGYN(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	string msg;
	if(GetSTROpValue(ops[0], msg))
	{
		int ret = MessageBox(hwmain, msg.c_str(), "OllyScript", MB_ICONQUESTION | MB_YESNO | MB_TOPMOST);
		if(ret == IDYES)
			variables["$RESULT"] = 1;
		else
			variables["$RESULT"] = 0;

		return true;
	}
	return false;
}

bool OllyLang::DoOR(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD dw1, dw2;
	if(GetDWOpValue(ops[0], dw1) && GetDWOpValue(ops[1], dw2))
	{
		args = ops[0] + ", " + ultoa(dw1 | dw2, buffer, 16);
		return DoMOV(args);
	}
	return false;
}

bool OllyLang::DoPAUSE(string args)
{
	return Pause();
}

bool OllyLang::DoREPL(string args)
{
	string ops[4];
	if(!CreateOperands(args, ops, 4))
		return false;

	if(ops[1].length() % 2 != 0 || ops[2].length() % 2 != 0)
	{
		errorstr = "Hex string must have an even number of characters!";
		return false;
	}

	DWORD addr, len;
	if(GetDWOpValue(ops[0], addr) && UnquoteString(ops[1], '#', '#') && UnquoteString(ops[2], '#', '#') && GetDWOpValue(ops[3], len))
	{
		// Replace
		char *membuf = 0;
		t_memory* tmem = Findmemory(addr);
		membuf = new char[len];
		int memlen = Readmemory(membuf, addr, len, MM_RESILENT);
		bool replaced = false;

		try
		{
			int i = 0;
			while(i < len)
			{
				replaced = Replace(membuf + i, ops[1].c_str(), ops[2].c_str(), ops[2].length()) || replaced;
				i++;
			}
		}
		catch(char* str)
		{
			errorstr = errorstr.append(str);
			delete [] membuf;
			return false;
		}
		
		if(replaced)
		{
			Writememory(membuf, addr, len, MM_DELANAL | MM_SILENT);
			Broadcast(WM_USER_CHALL, 0, 0);
		}

		delete [] membuf;

		return true;
	}

	return false;
}

bool OllyLang::DoRESET(string args)
{
	Sendshortcut(PM_MAIN, 0, WM_KEYDOWN, 1, 0, VK_F2); 
	return true;
}

bool OllyLang::DoRET(string args)
{
	Reset();
	MessageBox(hwmain, "Script finished", "OllyScript", MB_ICONINFORMATION | MB_OK | MB_TOPMOST);
	return true;
}

bool OllyLang::DoRTR(string args)
{
	Sendshortcut(PM_MAIN, 0, WM_KEYDOWN, 1, 0, VK_F9); 
	require_ollyloop = 1;
	return true;
}

bool OllyLang::DoRTU(string args)
{
	PostMessage(hwmain, WM_SYSKEYDOWN, VK_F9, 0);
	require_ollyloop = 1;
	return true;
}

bool OllyLang::DoRUN(string args)
{
	Go(Getcputhreadid(), 0, STEP_RUN, 0, 1);
	require_ollyloop = 1;
	return true;
}

bool OllyLang::DoSHL(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD dw1, dw2;
	if(GetDWOpValue(ops[0], dw1) && GetDWOpValue(ops[1], dw2))
	{
		args = ops[0] + ", " + ultoa(dw1 << dw2, buffer, 16);
		return DoMOV(args);
	}
	return false;
}

bool OllyLang::DoSHR(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD dw1, dw2;
	if(GetDWOpValue(ops[0], dw1) && GetDWOpValue(ops[1], dw2))
	{
		args = ops[0] + ", " + ultoa(dw1 >> dw2, buffer, 16);
		return DoMOV(args);
	}
	return false;
}

bool OllyLang::DoSTI(string args)
{
	Go(Getcputhreadid(), 0, STEP_IN, 0, 1);
	require_ollyloop = 1;
	return true;
}

bool OllyLang::DoSTO(string args)
{
	Go(Getcputhreadid(), 0, STEP_OVER, 0, 1);
	require_ollyloop = 1;
	return true;
}

bool OllyLang::DoSUB(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD dw1, dw2;
	if(GetDWOpValue(ops[0], dw1) && GetDWOpValue(ops[1], dw2))
	{
		args = ops[0] + ", " + ultoa(dw1 - dw2, buffer, 16);
		return DoMOV(args);
	}
	return false;
}

bool OllyLang::DoTI(string args)
{
	Sendshortcut(PM_MAIN, 0, WM_KEYDOWN, 1, 0, VK_F11); 
	require_ollyloop = 1;
	return true;
}

bool OllyLang::DoTICND(string args)
{
	string ops[1];
	string condition;

	if(!CreateOperands(args, ops, 1))
		return false;

	if(GetSTROpValue(ops[0], condition))
	{
		char* buffer = new char[condition.length() + 1];
		strcpy(buffer, condition.c_str());
		if(Runtracesize() == 0) 
		{
			ulong threadid = Getcputhreadid();
			if(threadid == 0)
				threadid = Plugingetvalue(VAL_MAINTHREADID);
			t_thread* pthr = Findthread(threadid);
			if(pthr != NULL)
				Startruntrace(&(pthr->reg)); 
		}
		Settracecondition(buffer, 0, 0, 0, 0, 0);
		Sendshortcut(PM_MAIN, 0, WM_KEYDOWN, 1, 0, VK_F11); 
		require_ollyloop = 1;
		return true;
	}
	return false;
}

bool OllyLang::DoTO(string args)
{
	Sendshortcut(PM_MAIN, 0, WM_KEYDOWN, 1, 0, VK_F12); 
	require_ollyloop = 1;
	return true;
}

bool OllyLang::DoTOCND(string args)
{
	string ops[1];
	string condition;

	if(!CreateOperands(args, ops, 1))
		return false;

	if(GetSTROpValue(ops[0], condition))
	{
		char* buffer = new char[condition.length() + 1];
		strcpy(buffer, condition.c_str());
		if(Runtracesize() == 0) 
		{
			ulong threadid = Getcputhreadid();
			if(threadid == 0)
				threadid = Plugingetvalue(VAL_MAINTHREADID);
			t_thread* pthr = Findthread(threadid);
			if(pthr != NULL)
				Startruntrace(&(pthr->reg)); 
		}
		Settracecondition(buffer, 0, 0, 0, 0, 0);
		Sendshortcut(PM_MAIN, 0, WM_KEYDOWN, 1, 0, VK_F12); 
		require_ollyloop = 1;
		return true;
	}
	return false;
}

bool OllyLang::DoVAR(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	if(reg_names.find(ops[0]) == reg_names.end())
	{
		variables.insert(pair<string, var> (ops[0], 0));
		return true;
	}
	errorstr = "Bad variable name: " + ops[0];
	return false;
}

bool OllyLang::DoXOR(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD dw1, dw2;
	if(GetDWOpValue(ops[0], dw1) && GetDWOpValue(ops[1], dw2))
	{
		args = ops[0] + ", " + ultoa(dw1 ^ dw2, buffer, 16);
		return DoMOV(args);
	}
	return false;
}

bool OllyLang::DoNOT(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	DWORD dw1;
	if(GetDWOpValue(ops[0], dw1)) 
	{
		args = ops[0] + ", " + ultoa(~dw1, buffer, 16);
		return DoMOV(args);
	}
	return false;
}

bool OllyLang::DoTEST(string args)
{
	string ops[2];

	if(!CreateOperands(args, ops, 2))
		return false;

	DWORD dw1, dw2;

	if(GetDWOpValue(ops[0], dw1) && GetDWOpValue(ops[1], dw2))
	{
		zf = 0;

		if (!(dw1 & dw2)) {
			zf = 1;
		}
	}
	return true;
}

bool OllyLang::DoPOP(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	DWORD dw1;

	if(GetDWOpValue(ops[0], dw1))
	{
		args = ops[0] + ", [esp]";
		DoMOV(args);
		args = "esp, 4";
		DoADD(args);
		return true;
	}
	return true;
}

bool OllyLang::DoPUSH(string args)
{
	string ops[1];

	if(!CreateOperands(args, ops, 1))
		return false;

	DWORD dw1;

	if(GetDWOpValue(ops[0], dw1))
	{
		args = "esp, 4";
		DoSUB(args);
		args = "[esp], " + ops[0];
		DoMOV(args);
		return true;
	}
	return true;
}

bool OllyLang::DoXCHG(string args) 
{
	string ops[2];

	if (!CreateOperands(args, ops, 2))
		return false;

	DWORD dw1, dw2;

	if (GetDWOpValue(ops[0], dw1) && GetDWOpValue(ops[1], dw2)) {
		args = ops[0] + ", " + ultoa(dw1, buffer, 16);
		DoMOV(args);
		args = ops[1] + ", " + ultoa(dw2, buffer, 16);
		DoMOV(args);
		return true;
	}

	return false;
}

bool OllyLang::DoLEA(string args)
{
	string ops[2];

	if (!CreateOperands(args, ops, 2))
		return false;

	DWORD dw1;

	if (GetDWOpValue(ops[0], dw1) && is_expr(ops[1])) {
		if(UnquoteString(ops[1], '[', ']')) {
			args = ops[0] + ", " + ultoa(calc_expr(ops[1]), buffer, 16);
			DoMOV(args);
			return true;
		}
	}

	return false;
}

bool OllyLang::DoCOMMENT(string args) 
{
	string ops[2];
	
	if (!CreateOperands(args, ops, 2)) {

		// Current eip is taken, if nothing else is been specified!
		ops[0] = "eip";
		ops[1] = args;
	}

	DWORD dw1;

	if (!GetDWOpValue(ops[0], dw1)) {
		return false;
	}

	//
	// Walk around for .c_str() returning consts and Insertname() doesn't stand up to it.
	//

	char *str = strdup(ops[1].c_str());
	
	if (!str) {
		return false;
	}

	Insertname(dw1, NM_COMMENT, str);

	free(str);

	return true;
}