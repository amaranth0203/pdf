
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the ODBGSCRIPT_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// ODBGSCRIPT_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef ODBGSCRIPT_EXPORTS
#define ODBGSCRIPT_API __declspec(dllexport)
#else
#define ODBGSCRIPT_API __declspec(dllimport)
#endif

// This class is exported from the ODbgScript.dll
//class ODBGSCRIPT_API CODbgScript {
//public:
//	CODbgScript(void);
	// TODO: add your methods here.
//};

//extern ODBGSCRIPT_API int nODbgScript;

//ODBGSCRIPT_API int fnODbgScript(void);

#pragma once

#define VERSIONHI      0               // High plugin version
#define VERSIONLO      93              // Low plugin version

static HINSTANCE hinst;                // DLL instance
static HWND      hwmain;               // Handle of main OllyDbg window
static char      cmdlinewinclass[32];  // Name of command line window class
static int       poponstop;            // Foreground on pause

static void*	 pmemforexec;