#include "stdafx.h"

//NOTE : OllyDBG Main Menu is Static... so we need to store MRU for next OllyDbg start

void mruAddFile(HINSTANCE h, char* szFilePath) {
	
	char buf[4096] = {0};

	int n;
	char key[5];
	strcpy(key,"NRU ");

	for(n=1; n<=5; n++) { 
		key[3]=n + 0x30; //ASCII n
		ZeroMemory(&buf, sizeof(buf));
		Pluginreadstringfromini(h,key,buf,0);
		if (strcmp(buf,szFilePath)==0) {
			//Move File to first MRU
			key[3]='1';
			Pluginreadstringfromini(h,key,buf,0);
			Pluginwritestringtoini(h,key,szFilePath);
			key[3]=n + 0x30;
			Pluginwritestringtoini(h,key,buf);
			return;
		}
	}
	for(n=4; n>0; n--) {
		//Add File then Move others
		key[3]=n+0x30;
		ZeroMemory(&buf, sizeof(buf));
		Pluginreadstringfromini(h,key,buf,0);
		if (strlen(buf)) {
			key[3]=n+1+0x30;
			Pluginwritestringtoini(h,key,buf);
		}
	}
	
	key[3]='1';
	Pluginwritestringtoini(h, key, szFilePath);

}

int  mruGetMenu(HINSTANCE h, char* buf) {

	char buf2[4096] = {0};
	char key[5];
	char key2[5];
	int p=0;
	
	strcpy(key,"NRU ");
	strcpy(key2,"MRU ");

 	for(int n=1; n<=5; n++) {
		key[3]=n+0x30; //ASCII n
		key2[3]=key[3];

		ZeroMemory(&buf2, sizeof(buf2));
		Pluginreadstringfromini(h,key,buf2,0);
		Pluginwritestringtoini(h,key2, buf2);
		if (strlen(buf2)) {
			if (PathFileExists(buf2)) {
				buf[p]=0x32;   p++;
				buf[p]=key[3]; p++;
				buf[p]=0x20;   p++;
				
				strcpy(&buf[p],buf2); p+=strlen(buf2);
				buf[p]=',';p++; 

			}
		}
	}
	if (p>0) buf[--p]=0;

	return p;
}


//MessageBox(hwmain,buf,"",MB_OK|MB_ICONEXCLAMATION);