#pragma once

#ifdef _DEBUG
	#ifndef __GUICON_H__

	#define __GUICON_H__



	//#include "stdafx.h"

		void RedirectIOToConsole();

	#endif

#endif

/* End of File */

