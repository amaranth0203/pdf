#pragma once

bool Replace(char * s,const char * searchstr,const char * replstring,size_t length);
//bool CompareChar(const char src, char* cmp);
int FindWithWildcards(const char* source, const char* findstring, size_t len);
//char * Byte2Hex(char b);