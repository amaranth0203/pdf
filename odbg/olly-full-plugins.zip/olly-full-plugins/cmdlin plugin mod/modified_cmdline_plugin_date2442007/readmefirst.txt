this package contains the latest source of modified cmdline plugin for ollydbg
and a precompiled binary compiled with bcc5 free 

the redistributable.zip contains 

dbghlp.dll and symsrv.dll 

these two files are from windbg version 6.6.7.5 installation 

by using these files you agree to the licence and eula of the specified windbg version 6.6.7.5


for further comments bug reports and feature requests please 

visit 
http://www.openrce.org/blog/view/715/LoadPdb_added_to_my_modified_cmdline_plugin