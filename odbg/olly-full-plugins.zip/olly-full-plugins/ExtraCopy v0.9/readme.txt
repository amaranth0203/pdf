plugin: 
	ExtraCopy v0.90
authot:	
	Regon
description:
	This plugin correct references of relative jumps and calls at copy the block of instructions.

history:
	ExtraCopy v0.90
	Repaired determination a number of instruction in the block.
	Copy to the clipboard added

	ExtraCopy v0.80


For any bugs reports or comments mail to:
regon@talk21.com
