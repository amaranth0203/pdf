// OllyLang.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"

using namespace std;

OllyLang::OllyLang()
{
	script_state = SS_NONE;

	// Init array with register names
	reg_names.clear();
	reg_names.insert("eax");
	reg_names.insert("ebx");
	reg_names.insert("ecx");
	reg_names.insert("edx");
	reg_names.insert("esi");
	reg_names.insert("edi");
	reg_names.insert("esp");
	reg_names.insert("ebp");
	reg_names.insert("eip");
	reg_names.insert("ax");
	reg_names.insert("al");
	reg_names.insert("ah");
	reg_names.insert("bx");
	reg_names.insert("bl");
	reg_names.insert("bh");
	reg_names.insert("cx");
	reg_names.insert("cl");
	reg_names.insert("ch");
	reg_names.insert("dx");
	reg_names.insert("dl");
	reg_names.insert("dh");
	reg_names.insert("di");
	reg_names.insert("si");
	
	// Init map of 16/8regs names to 32 register name
	o_32regs["ax"] = "eax";
	o_32regs["al"] = "eax";
	o_32regs["ah"] = "eax";
	o_32regs["bx"] = "ebx";
	o_32regs["bl"] = "ebx";
	o_32regs["bh"] = "ebx";
	o_32regs["cx"] = "ecx";
	o_32regs["cl"] = "ecx";
	o_32regs["ch"] = "ecx";
	o_32regs["dx"] = "edx";
	o_32regs["dl"] = "edx";
	o_32regs["dh"] = "edx";
	o_32regs["di"] = "edi";
	o_32regs["si"] = "esi";

	// Init array of flag names
	flag_names.clear();
	flag_names.insert("!CF");
	flag_names.insert("!PF");
	flag_names.insert("!AF");
	flag_names.insert("!ZF");
	flag_names.insert("!SF");
	flag_names.insert("!DF");
	flag_names.insert("!OF");

	// Init command array
	commands["add"] = &OllyLang::DoADD;
	commands["ai"] = &OllyLang::DoAI;
	commands["an"] = &OllyLang::DoAN;
	commands["and"] = &OllyLang::DoAND;
	commands["ao"] = &OllyLang::DoAO;
	commands["ask"] = &OllyLang::DoASK;
	commands["asm"] = &OllyLang::DoASM;
	commands["bc"] = &OllyLang::DoBC;
	commands["bp"] = &OllyLang::DoBP;
	commands["bpcnd"] = &OllyLang::DoBPCND;
	commands["bphwc"] = &OllyLang::DoBPHWC;
	commands["bphws"] = &OllyLang::DoBPHWS;
	commands["bpl"] = &OllyLang::DoBPL;
	commands["bplcnd"] = &OllyLang::DoBPLCND;
	commands["bpmc"] = &OllyLang::DoBPMC;
	commands["bprm"] = &OllyLang::DoBPRM;
	commands["bpwm"] = &OllyLang::DoBPWM;
	commands["cmp"] = &OllyLang::DoCMP;
	commands["cmt"] = &OllyLang::DoCMT;
	commands["cob"] = &OllyLang::DoCOB;
	commands["coe"] = &OllyLang::DoCOE;
	commands["dbh"] = &OllyLang::DoDBH;
	commands["dbs"] = &OllyLang::DoDBS;
	commands["dec"] = &OllyLang::DoDEC;
	commands["dm"] = &OllyLang::DoDM;
	commands["dma"] = &OllyLang::DoDMA;
	commands["dpe"] = &OllyLang::DoDPE;
	commands["ende"] = &OllyLang::DoENDE;
	commands["esti"] = &OllyLang::DoESTI;
	commands["esto"] = &OllyLang::DoESTO;
	commands["eob"] = &OllyLang::DoEOB;
	commands["eoe"] = &OllyLang::DoEOE;
	commands["eval"] = &OllyLang::DoEVAL;
	commands["exec"] = &OllyLang::DoEXEC;
	commands["fill"] = &OllyLang::DoFILL;
	commands["find"] = &OllyLang::DoFIND;
//	commands["find_r"] = &OllyLang::DoFIND_R;
	commands["findop"] = &OllyLang::DoFINDOP;
	commands["findop_r"] = &OllyLang::DoFINDOP_R;
	commands["gn"] = &OllyLang::DoGN;
	commands["gmi"] = &OllyLang::DoGMI;
	commands["go"] = &OllyLang::DoGO;
	commands["gpa"] = &OllyLang::DoGPA;
	commands["inc"] = &OllyLang::DoINC;
	commands["ja"] = &OllyLang::DoJA;
	commands["jae"] = &OllyLang::DoJAE;
	commands["jb"] = &OllyLang::DoJB;
	commands["jbe"] = &OllyLang::DoJBE;
	commands["je"] = &OllyLang::DoJE;
	commands["jmp"] = &OllyLang::DoJMP;
	commands["jne"] = &OllyLang::DoJNE;
	commands["lbl"] = &OllyLang::DoLBL;
	commands["log"] = &OllyLang::DoLOG;
	commands["mov"] = &OllyLang::DoMOV;
	commands["msg"] = &OllyLang::DoMSG;
	commands["msgyn"] = &OllyLang::DoMSGYN;
	commands["or"] = &OllyLang::DoOR;
	commands["pause"] = &OllyLang::DoPAUSE;
	commands["repl"] = &OllyLang::DoREPL;
	commands["reset"] = &OllyLang::DoRESET;
	commands["ret"] = &OllyLang::DoRET;
	commands["rtr"] = &OllyLang::DoRTR;
	commands["rtu"] = &OllyLang::DoRTU;
	commands["run"] = &OllyLang::DoRUN;
	commands["shl"] = &OllyLang::DoSHL;
	commands["shr"] = &OllyLang::DoSHR;
	commands["sti"] = &OllyLang::DoSTI;
	commands["sto"] = &OllyLang::DoSTO;
	commands["sub"] = &OllyLang::DoSUB;
	commands["ti"] = &OllyLang::DoTI;
	commands["ticnd"] = &OllyLang::DoTICND;
	commands["to"] = &OllyLang::DoTO;
	commands["tocnd"] = &OllyLang::DoTOCND;
	commands["ubp"] = &OllyLang::DoBP;
	commands["var"] = &OllyLang::DoVAR;
	commands["xor"] = &OllyLang::DoXOR;
	commands["not"] = &OllyLang::DoNOT;
	commands["test"] = &OllyLang::DoTEST;
	commands["pop"] = &OllyLang::DoPOP;
	commands["push"] = &OllyLang::DoPUSH;
	commands["xchg"] = &OllyLang::DoXCHG;
	commands["lea"] = &OllyLang::DoLEA;
	commands["comment"] = &OllyLang::DoCOMMENT;
	
	script_state = SS_INITIALIZED;
	script_pos = 0;
	EOB_row = -1;
	EOE_row = -1;
	zf = 0;
	cf = 0;
	enable_logging = false;
}

OllyLang::~OllyLang()
{
	Reset();
}

vector<string> OllyLang::GetScriptFromFile(LPSTR file)
{
	vector<string> script;
	string scriptline;
	ifstream fin(file, ios::in);

	while(getline(fin, scriptline))
		script.push_back(scriptline);

	fin.close();

	return script;
}

int OllyLang::InsertScript(vector<string> toInsert, int posInScript)
{
	vector<string>::iterator iter = toInsert.begin();

	string scriptline;
	int inc_pos = -1, linesAdded = 0;
	bool is_comment = false;

	while(iter != toInsert.end())
	{
		scriptline = trim(*iter);
		// Handle comments
		if(scriptline == "/*")
		{
			is_comment = true;
			iter++;
			continue;
		}
		else if(scriptline == "*/")
		{
			is_comment = false;
			iter++;
			continue;
		}
		else if(is_comment || scriptline.find("//") == 0)
		{
			iter++;
			continue;
		}

		string lcline = scriptline;
		int (*pf)(int)=tolower; 
		transform(lcline.begin(), lcline.end(), lcline.begin(), pf);

		// If not empty add to script vector
		if(scriptline != "")
		{
			// Check for comments at the end of rows and erase those
			if(scriptline.find("//") > 0)
			{
				scriptline = trim(scriptline.substr(0, scriptline.find("//")));
			}
			// Check for #inc and include file if it exists, else add line
			if((inc_pos = lcline.find("#inc")) > -1)
			{
				cout << inc_pos;
				string args = trim(scriptline.substr(inc_pos + 4, scriptline.length()));
				string filename;
				if(GetSTROpValue(args, filename))
				{
					vector<string> newScript = GetScriptFromFile((LPSTR)filename.c_str());
					posInScript += InsertScript(newScript, posInScript);
					iter++;
					continue;
				}
				else
				{
					MessageBox(hwmain, "Bad #inc directive!", "OllyScript", MB_OK | MB_ICONERROR);
				}
			}
			// Logging
			else if((inc_pos = lcline.find("#log")) > -1)
			{
				enable_logging = true;
			}
			else
			{
				script.insert(script.begin() + posInScript, scriptline);
				linesAdded++;
				posInScript++;
			}
		}
		iter++;
	}
	return linesAdded;
}

int OllyLang::GetState()
{
	return script_state;
}

bool OllyLang::LoadScript(LPSTR file)
{
	Reset();

	vector<string> unparsedScript = GetScriptFromFile(file);
	InsertScript(unparsedScript, 0);

	// Find all labels
	ParseLabels();

	script_state = SS_LOADED;

	return true;
}

bool OllyLang::Pause()
{
	if(script_state == SS_RUNNING)
	{
		script_state = SS_PAUSED;
		return true;
	}

	return false;
}

bool OllyLang::Reset()
{
	script.clear();
	labels.clear();
	variables.clear();
	char s[10] = {0};
	sprintf(s,"%i.%i", VERSIONHI, VERSIONLO);
	string str(s);
	variables["$VERSION"] = str;
	script_pos = 0;
	EOB_row = -1;
	EOE_row = -1;
	script_state = SS_NONE;
	enable_logging = false;
	return true;
}

bool OllyLang::Resume()
{
	if(script_state == SS_PAUSED)
	{
		script_state = SS_RUNNING;
		return true;
	}

	return false;
}

bool OllyLang::Step(int forceStep)
{
	require_ollyloop = 0;

	t_status st = Getstatus();

	while(!require_ollyloop && st == STAT_STOPPED && 
		   (script_state == SS_RUNNING || 
		    script_state == SS_LOADED || 
		   (script_state == SS_PAUSED && forceStep )))
	{
		// Set state to RUNNING
		if(forceStep == 0)
			script_state = SS_RUNNING;

		// Check if script out of bounds
//		DumpScript();
		if(script.size() <= script_pos)
			return false;

		// Get code line
		string codeLine = trim(script[script_pos]);

		// Log line of code if that is enabled
		if(enable_logging)
		{
			char buffer[4096] = {0};
			strcpy(buffer, "--> ");
			strcat(buffer, codeLine.c_str());
			Addtolist(0, -1, buffer);
		}

		// Check if its a label
		if (codeLine[codeLine.length() - 1] != ':')
		{

			// Create command and arguments
			string command = codeLine;
			string args = "";
			size_t pos = codeLine.find_first_of(" \t\r\n");
			if(pos != -1)
			{
				command = trim(codeLine.substr(0, pos));
				int (*pf)(int)=tolower; 
				transform(command.begin(), command.end(), command.begin(), pf);
				args = trim(codeLine.substr(pos));
			}
			
			bool result = false;

			// Find command and execute it
			if(commands.find(command) != commands.end())
			{
				// Command found, execute it
				PFCOMMAND func = commands[command];
				result = (this->*func)(args);
			}
			else 
			{
				// No such command
				errorstr = "No such command: " + codeLine;
			}

			// Error in processing, show error and die
			if(!result)
			{
				string message = "Error on line ";
				char buffer[4096] = {0};
				message.append(itoa(script_pos + 1, buffer, 10));
				message.append("\n");
				message.append("Text: ");
				message.append(script.at(script_pos));
				message.append("\n");
				if(errorstr != "")
				{
					message.append(errorstr);
					message.append("\n");
				}
				MessageBox(hwmain, message.c_str(), "OllyScript error!", MB_ICONERROR | MB_OK);
				errorstr = "";
				Reset();

				return false;
			}
		} // If Is Label
		script_pos++;
		if(forceStep == 1)
			break;
	}

	return true;
}

bool OllyLang::OnBreakpoint()
{
	if(EOB_row > -1)
	{
		script_pos = EOB_row;
		return true;
	}
	else

		return false;
}

bool OllyLang::OnException(DWORD ExceptionCode)
{
	if(EOE_row > -1)
	{
		script_pos = EOE_row;
		return true;
	}
	else
		return false;
}

bool OllyLang::CreateOperands(string& args, string ops[], uint len)
{
   if(len == 1)
	{
		if(args.find(',') != -1 && args.at(0) != '"' && args.at(args.length() - 1) != '"')
			return false;

		if(args.length() == 0)
			return false;

		ops[0] = args;
		return true;
	}
	else
	{
		vector<string> v;
		if(split(v, args, ',') && v.size() == len)
		{
			for(uint i = 0; i < len; i++)
				ops[i] = trim(v[i]);
			return true;
		}
		return false;
	}
}

bool OllyLang::ParseLabels()
{
	vector<string>::iterator iter;
	iter = script.begin();
	string s;
	int loc = 0;

	while(iter != script.end())
	{
		s = *iter;
		if(s.at(s.length() - 1) == ':')
			labels.insert(pair<string, int>(s.substr(0, s.length() - 1), loc));
		iter++;
		loc++;
	}

	return false;
}

bool OllyLang::GetANYOpValue(string op, string &value, bool hex8char)
{
	if(variables.find(op) != variables.end())
	{
		// We have a declared variable
		if(variables[op].vt == STR)
		{
			// It's a string var, return value
			value = variables[op].str;
			return true;
		}
		else if(variables[op].vt == DW)
		{
			char buffer[255] = {0};
			if(hex8char)
				sprintf(buffer, "0%08X", variables[op].dw);
			else
				sprintf(buffer, "%X", variables[op].dw);
			value = buffer;
			return true;
		}
		return false;
	}
	else if(UnquoteString(op, '"', '"')) 
	{
		value = op;
		return true;
	}
	else if(is_hex(op))
	{
		value = op;
		return true;
	}
	return false;
}

bool OllyLang::GetSTROpValue(string op, string &value)
{
	if(variables.find(op) != variables.end())
	{
		// We have a declared variable
		if(variables[op].vt == STR)
		{
			// It's a string var, return value
			value = variables[op].str;
			return true;
		}
//		else if(variables[op].vt == DW)
//		{
//			DWORD out = 0;
//			if(GetDWOpValue(op, out))
//			{
//				value = out;
//				return true;
//			}
//		}
		return false;
	}
	else if(UnquoteString(op, '"', '"')) 
	{
		value = op;
		return true;
	}
	return false;
}

int OllyLang::GetRegNr(string& name)
{
	if(name == "eax")
		return REG_EAX;
	else if(name == "ecx")
		return REG_ECX;
	else if(name == "edx")
		return REG_EDX;
	else if(name == "ebx")
		return REG_EBX;
	else if(name == "esp")
		return REG_ESP;
	else if(name == "ebp")
		return REG_EBP;
	else if(name == "esi")
		return REG_ESI;
	else if(name == "edi")
		return REG_EDI;
	return -1;
}

bool OllyLang::GetDWOpValue(string op, DWORD &value)
{
	if(is_register(op))
	{
		// We have a register
		int regnr = GetRegNr(op);
		t_thread* pt = Findthread(Getcputhreadid());
		
		if(regnr != -1)
		{
			// It's a usual register
			value = pt->reg.r[regnr];
			return true;
		}
		else if(op == "eip")
		{
			// It's EIP
			value = pt->reg.ip;
			return true;
		} else {

			// It's a 16/8bit register!
			regnr = GetRegNr(o_32regs[op]);
			value = pt->reg.r[regnr];
			
			// The string (?x || ?i) mask, meaning it's a 16bit register!
			if (op[1] == 'x' || op[1] == 'i' ) {
				value &= 0x0000FFFF;
				return true;
			}

			// The string (?l) mask, meaning it's a 8bit register (lower part)
			if (op[1] == 'l') {
				value &= 0x000000FF;
				return true;
			}

			// The string (?h) mask, meaning it's a 8bit register (upper part)
			if (op[1] == 'h') {
				value &= 0x0000FF00;
				return true;
			}

		}
		return false;
	}
	else if(is_flag(op))
	{
		eflags flags;
		ZeroMemory(&flags, sizeof DWORD);
		t_thread* pt = Findthread(Getcputhreadid());
        flags.dwFlags = pt->reg.flags;

		if(stricmp(op.c_str(), "!af") == 0)
			value = flags.bitFlags.AF;
		else if(stricmp(op.c_str(), "!cf") == 0)
			value = flags.bitFlags.CF;
		else if(stricmp(op.c_str(), "!sf") == 0)
			value = flags.bitFlags.DF;
		else if(stricmp(op.c_str(), "!of") == 0)
			value = flags.bitFlags.OF;
		else if(stricmp(op.c_str(), "!pf") == 0)
			value = flags.bitFlags.PF;
		else if(stricmp(op.c_str(), "!sf") == 0)
			value = flags.bitFlags.SF;
		else if(stricmp(op.c_str(), "!zf") == 0)
			value = flags.bitFlags.ZF;
		
		return true;
	}
	else if(is_variable(op))
	{
		// We have a declared variable
		if(variables[op].vt == DW)
		{
			// It's a DWORD var, return value
			value = variables[op].dw;
			return true;
		}
		return false;
	}
	else if(is_hex(op))
	{
		// We have a HEX constant
		op = "0" + op;
		value = strtoul(op.c_str(), 0, 16);
		return true;
	}
	else if(UnquoteString(op, '[', ']'))
	{
		// We have a memory address
		DWORD addr = 0;

		// Is it an expression or a standard operand?
		if (is_expr(op)) {

			addr = calc_expr(op);

		} else if(is_register(op) || is_hex(op) || is_variable(op)) {

			GetDWOpValue(op, addr);

		}

		Readmemory(&value, addr, 4, MM_SILENT);
		return true;
	}
	return false;
}

bool OllyLang::is_expr(string s) 
{
	bool retval = false;

	for (int i = 0; i < s.length(); i++) {
		if (s[i] == '+' || s[i] == '-') {
			retval = true;
			break;
		}
	}

	return retval;
}

DWORD OllyLang::calc_recursive_walk(string s, int offset, int carry, char lastop) {
	int len = s.length();
	int i;
	DWORD op_value;

	// Walk on the expression
	for (i = offset; i < len; i++) {
		
		// Is it an action char?
		if (s[i] == '+' || s[i] == '-') {
			break;
		}
	}

	// Extract the token
	basic_string <char> cur_op (s.begin()+offset ,s.begin()+i);
	
	// Query the token value
	if (!GetDWOpValue(cur_op, op_value)) {

		// Token has no value? Ball out!
		op_value = 0;

	}

	// What we need to do now?
	switch (lastop) {

		// Add to carry
		case '+':
			carry += op_value;
			break;

		// Sub from carry
		case '-':
			carry -= op_value;
			break;

	}

	// Go for another walk or stop here?
	if (i >= s.length()) {
		return carry; // Final sum!
	}

	return calc_recursive_walk(s, i+1, carry, s[i]);
}

DWORD OllyLang::calc_expr(string s) {	

	// Start recursive walk upon the expression
	return calc_recursive_walk(s, 0, 0, '+');
}

bool OllyLang::is_register(string s)
{
	int (*pf)(int) = tolower; 
	transform(s.begin(), s.end(), s.begin(), pf);

	if(reg_names.find(s) != reg_names.end())
		return true;
	return false;
}

bool OllyLang::is_flag(string s)
{
	int (*pf)(int) = toupper; 
	transform(s.begin(), s.end(), s.begin(), pf);

	if(flag_names.find(s) != flag_names.end())
		return true;
	return false;
}

bool OllyLang::is_variable(string &s)
{
	if(variables.find(s) != variables.end())
		return true;
	return false;
}

string OllyLang::ResolveVarsForExec(string in)
{
	string out, varname;
	bool in_var = false;
	in = trim(in);

	for(int i = 0; i < in.length(); i++)
	{
		if(in[i] == '{')
		{
			in_var = true;
		}
		else if(in[i] == '}')
		{
			in_var = false;
			GetANYOpValue(varname, varname, true);
			out += varname;
			varname = "";
		}
		else
		{
			if(in_var)
				varname += in[i];
			else
				out += in[i];
		}
	}
	return out;
}

void OllyLang::DumpLabels()
{
	cerr << "_ LABELS _" << endl;
	map<string, int>::iterator iter;
	iter = labels.begin();

	pair<string, int> p;
	while(iter != labels.end())
	{
		p = *iter;

		cerr << "Name: " << p.first << ", ";
		cerr << "Row: " << p.second << endl;
		iter++;
	}
	cerr << endl;
}

void OllyLang::DumpVars()
{
	cerr << "_ VARS _" << endl;
	map<string, var>::iterator iter;
	iter = variables.begin();

	pair<string, var> p;
	while(iter != variables.end())
	{
		p = *iter;

		cerr << "Name: " << p.first << ", ";
		cerr << "Value: " << hex << p.second.dw << endl;
		iter++;
	}
	cerr << endl;
}

void OllyLang::DumpScript()
{
	cerr << "_ SCRIPT _" << endl;
	vector<string>::iterator iter;
	iter = script.begin();

	while(iter != script.end())
	{
		cerr << "--> " << *iter << endl;
		iter++;
	}
	cerr << endl;
}