#pragma once

#include "stdafx.h"
#include "var.h"
#include "Search.h"

typedef unsigned long DWORD;
typedef unsigned int uint;
typedef unsigned char BYTE;

enum {SS_NONE, SS_INITIALIZED, SS_LOADED, SS_RUNNING, SS_PAUSED};

using namespace std;

class OllyLang
{
public:
	// Constructor & destructor
	OllyLang();
	~OllyLang();
	
	// Public methods
	int GetState();
	bool LoadScript(LPSTR fileName);
	bool Pause();
	bool Resume();
	bool Reset();
	bool Step(int forceStep);

	// "Events"
	bool OnBreakpoint();
	bool OnException(DWORD ExceptionCode);

private:
	typedef bool (OllyLang::*PFCOMMAND)(string);

	union eflags
	{
		DWORD dwFlags;
		struct flagbits
		{
			unsigned CF : 1;
			unsigned dummy1 : 1;
			unsigned PF : 1;
			unsigned dummy2 : 1;
			unsigned AF : 1;
			unsigned dummy3 : 1;
			unsigned ZF : 1;
			unsigned SF : 1;
			unsigned TF : 1;
			unsigned IF : 1;
			unsigned DF : 1;
			unsigned OF : 1;
		} bitFlags;
	};

	//
	// Packed registers (32, 16) for 16/8bits register support
	//

	struct p_reg16 {
		unsigned int l_byte:8;
		unsigned int u_byte:8;
	};

	struct p_reg32 {
		struct p_reg16 l_word;
		unsigned int u_word:16;
	};

	// The script that is being executed
	vector<string> script;
	// Commands that can be executed
	map<string, PFCOMMAND> commands;
	// Variables that exist
	map<string, var> variables;
	// Labels that exist
	map<string, int> labels;
	// Possible register names
	set<string> reg_names;
	// Possible flag names
	set<string> flag_names;
	// Mapping from 16/8regs names to 32bit register name
	map<string, string> o_32regs;

	bool require_ollyloop;
	bool enable_logging;
	uint script_pos;
	int script_state;
	int EOB_row;
	int EOE_row;
	string errorstr;
	// Pseudo-flags to emulate CMP
	BYTE zf, cf;

	// Commands
	bool DoADD(string args);
	bool DoAI(string args);
	bool DoAN(string args);
	bool DoAND(string args);
	bool DoAO(string args);
	bool DoASK(string args);
	bool DoASM(string args);
	bool DoBC(string args);
	bool DoBP(string args);
	bool DoBPCND(string args);
	bool DoBPHWC(string args);
	bool DoBPHWS(string args);
	bool DoBPL(string args);
	bool DoBPLCND(string args);
	bool DoBPMC(string args);
	bool DoBPRM(string args);
	bool DoBPWM(string args);
	bool DoCMP(string args);
	bool DoCMT(string args);
	bool DoCOB(string args);
	bool DoCOE(string args);
	bool DoDBH(string args);
	bool DoDBS(string args);
	bool DoDEC(string args);
	bool DoDM(string args);
	bool DoDMA(string args);
	bool DoDPE(string args);
	bool DoENDE(string args);
	bool DoEOB(string args);
	bool DoEOE(string args);
	bool DoESTI(string args);
	bool DoESTO(string args);
	bool DoEVAL(string args);
	bool DoEXEC(string args);
	bool DoFILL(string args);
	bool DoFIND(string args);
//	bool DoFIND_R(string args);
	bool DoFINDOP(string args);
	bool DoFINDOP_R(string args);
	bool DoGN(string args);
	bool DoGMI(string args);
	bool DoGO(string args);
	bool DoGPA(string args);
	bool DoINC(string args);
	bool DoJA(string args);
	bool DoJAE(string args);
	bool DoJB(string args);
	bool DoJBE(string args);
	bool DoJE(string args);
	bool DoJMP(string args);
	bool DoJNE(string args);
	bool DoLOG(string args);
	bool DoLBL(string args);
	bool DoMOV(string args);
	bool DoMSG(string args);
	bool DoMSGYN(string args);
	bool DoOR(string args);
	bool DoPAUSE(string args);
	bool DoREPL(string args);
	bool DoRESET(string args);
	bool DoRET(string args);
	bool DoRTR(string args);
	bool DoRTU(string args);
	bool DoRUN(string args);
	bool DoSHL(string args);
	bool DoSHR(string args);
	bool DoSTI(string args);
	bool DoSTO(string args);
	bool DoSUB(string args);
	bool DoTI(string args);
	bool DoTICND(string args);
	bool DoTO(string args);
	bool DoTOCND(string args);
	bool DoVAR(string args);
	bool DoXOR(string args);
	bool DoNOT(string args);
	bool DoTEST(string args);
	bool DoPOP(string args);
	bool DoPUSH(string args);
	bool DoXCHG(string args);
	bool DoLEA(string args);
	bool DoCOMMENT(string args);

	// Helper functions
	vector<string> GetScriptFromFile(LPSTR fileName);
	int InsertScript(vector<string> toInsert, int posInScript);
	bool CreateOperands(string& opstring, string ops[], uint len);
	bool GetDWOpValue(string op, DWORD &value);
	bool GetSTROpValue(string op, string &value);
	bool GetANYOpValue(string op, string &value, bool hex8char);

	int GetRegNr(string& name);
	bool is_register(string s);
	bool is_flag(string s);
	bool is_variable(string& s);
	bool is_expr(string s);
	DWORD calc_expr(string s);
	DWORD calc_recursive_walk(string s, int offset, int carry, char lastop);
	bool ParseLabels();
	bool Process(string& codeLine);

	string ResolveVarsForExec(string in);

	// Debug functions
	void DumpVars();
	void DumpLabels();
	void DumpScript();
};

// General functions
string ToLower(string in);
int searchx(char *SearchBuff, int BuffSize, char *SearchString, int StringLen, char wc);
bool GetWildcardBytePositions(string bytestring, vector<int>* wildcardpos);
bool RgchContains(char* container, uint containerlen, char* containee, uint containeelen);
bool is_hex(string& s);
bool split(vector<string> &vec, const string &str, const char delim);
char GetWildcard(string &s);
int Str2Rgch(string &s, char* arr, uint size);
int Str2RgchWithWC(string &s, char* arr, uint size, char wc);
string trim(const string& sData);
bool UnquoteString(string& s, char cstart, char cend);

// PE Dumper
bool SaveDump(string fileName, DWORD ep);
bool GetPEInfo(DWORD ep);

// Dialogs
INT_PTR CALLBACK InputDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);