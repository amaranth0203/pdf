DLLBreakEx v1.2 - E3

History:
v1.2
  + Static version (no runtime)
  * Added compatibility with 1.10b (ODBG_Paused)
  
v1.1
  + Added DLL Breakpoints List in Menu
  + Ignore other modules when bp is set
  * Bug with module cache on restart
  
v1.0 - Initial Release

Description : 
For debugged proggies which loads a lot of dll, with this plugin you can select a dll from harddrive. 
When this dll will be loaded, you will get an Alert MessageBox. 

Needs the debugging option event : Break on new module (DLL) 

Tested on odbg 1.10c 

Sources Compiled with : 

BCB6.0 / Plugin SDK 1.10c 
