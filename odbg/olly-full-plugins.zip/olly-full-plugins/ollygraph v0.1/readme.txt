This plugin allows you to generate VCG-compatible function graphs 
much like the same functionality in IDA Pro. Unfortunately I've 
only had enough time to implement one function, which is the
"Generate Function Flowchart" option in the menu. The other option,
"Generate Function Call Graph" is not yet implemented. It might not
ever be implemented, but rather than sit on the code until it is 
completed (which might be never) I decided to release it as-is, and
maybe someone will find it useful, or wish to work on it further.

There are two more graph functions in IDA which are not implemented 
here, but function flowcharts are all anyone uses anyway, right? :p

I'm not sure if the graphs are 100% correct as IDA would output them,
but it appears as though they are in my tests. YMMV, of course.

The source is provided, feel free to implement the rest of the
functions if you really need them, or fix any bugs you find. And of 
course, share your changes/additions with the rest of the world!

You need to have Wingraph32 from IDA to display the generated graphs.
The source to this is available from Datarescue's site if you don't
have IDA and need to compile Wingraph32 yourself.

Joe Stewart
joe@joestewart.org

