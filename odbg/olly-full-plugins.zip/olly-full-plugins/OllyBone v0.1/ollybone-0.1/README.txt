OllyBonE v0.1
Break-on-Execute for OllyDbg
(c)2006 Joe Stewart <joe@joestewart.org>

You will need the OllyDbg PDK and the Windows DDK to compile from source.

Installation:
Copy ollybone.dll and i386/ollybone.sys to your OllyDbg directory.
