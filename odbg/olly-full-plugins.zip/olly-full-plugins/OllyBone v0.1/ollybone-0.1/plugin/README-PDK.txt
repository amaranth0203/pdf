Get the OllyDbg PDK and put ollydbg.lib and Plugin.h into this directory.
