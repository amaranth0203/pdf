aRC Olly-Admin 1.01


1) Translated to english
2) GUI fixed a bit and removed two BMP's "suck"
3) the plugins count limit was 31 but ollyadvanced supports 127 so i updated that !
4) i fixed the version three times one for my olly the second for the original and the third was for SND :D
5) Mm.......i forgot but enjoy it and anything isn't working just say it !!

Original By aRC & Modified By Angel-55