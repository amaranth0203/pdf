MemoryWatch(MW) Ollydbg 1.10 plugin provides functions which allow a debugged app to be automatically stepped while watching for a particular memory value(s), register value(s) and/or string value(s). MW can pause when a watch value is found(option) or log watch events to the Ollydbg log file(option).

The MW stepping can be set as 'step in' (F7), 'step over' (F8) or run (F9) to hardware/software breakpoints(option).

Installation : Copy to the Ollydbg plugin folder

Read the MemoryWatch help information