////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                          OllyStepNSearch plugin                            //
//                                                                            //
//                   2006 Didier Stevens http://DidierStevens.com             //
//                                                                            //
// This plugin allows you to search for a given text when automatically       //
// stepping through the debugged program.                                     //
//                                                                            //
// This code is in the public domain, there is no Copyright.                  //
// Use at your own risk.                                                      //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

// VERY IMPORTANT NOTICE: COMPILE THIS DLL WITH BYTE ALIGNMENT OF STRUCTURES
// AND UNSIGNED CHAR!

// History:
//  19/08/2006 no version number	Development started
//	26/08/2006 version 0.5.0			Development resumed

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>

#include "plugin.h"

// Fields used by the plugin in OllyDbg.ini
#define INI_VERSION "Version"
#define INI_SEARCH "Search"
#define INI_STEPINTOLIMIT "StepIntoLimit"

char			*szVersion = "0.5.0";
HINSTANCE	hiDLL;												// DLL instance
HWND			hwMain;												// Handle of main OllyDbg window
int				iFlagEnableStepSearch;				// Flag, true when the user wants to enable the OllyStepNSearch plugin
ulong			ulStepInLimit;								// Minimum address, we don't want to StepSearch from this address on and step in
char			achSearchText[TEXTLEN];				// Text the user wants to search for
int				iFlagSearchForSearchText;			// Flag, true when we want to search for text and break when found
ulong			ulRegPrev[8];									// Array to store the previous value of the registers
int				iFlagRegPrevNotInitialized;		// Flag, true when ulRegPrev contains no data
int				iStep;												// Indicates the step we take (step in / step over)
char			*aszRegName[] = 							// Names of the registers
					{"EAX", "ECX", "EDX", "EBX", "ESP", "EBP", "ESI", "EDI"};

// Load settings from OllyDbg.ini and define default values when settings not set in INI file
void LoadFromOllyDbgIni(void)
{
	char achBuf[TEXTLEN];
	ulong ulResult;	
	char *szError;

//	Pluginwritestringtoini(hiDLL, INI_VERSION, szVersion);
//	Pluginwritestringtoini(hiDLL, INI_SEARCH, "P@ssw0rd");
//	Pluginwritestringtoini(hiDLL, INI_STEPINTOLIMIT, "0x10000000");

	Pluginreadstringfromini(hiDLL, INI_SEARCH, achSearchText, "");
	iFlagSearchForSearchText = strcmp(achSearchText, "") == 1;
		
	Pluginreadstringfromini(hiDLL, INI_STEPINTOLIMIT, achBuf, "0x10000000");
	ulResult = strtoul(achBuf, &szError, 0);
	if (*szError != '\0' || ulResult == ULONG_MAX)
		ulStepInLimit = 0x10000000;
	else
		ulStepInLimit = ulResult;

  Addtolist(0, 0, "OllyStepNSearch achSearchText = %s", achSearchText);
  Addtolist(0, 0, "OllyStepNSearch ulStepInLimit = %08lX", ulStepInLimit);
}

// Entry point into a plugin DLL. Many system calls require DLL instance
// which is passed to DllEntryPoint() as one of parameters. Remember it.
// Preferrable way is to place initializations into ODBG_Plugininit() and
// cleanup in ODBG_Plugindestroy().
BOOL WINAPI DllEntryPoint(HINSTANCE hi, DWORD reason, LPVOID reserved) {
  if (reason == DLL_PROCESS_ATTACH)
    hiDLL=hi;                          // Mark plugin instance
  return 1;                            // Report success
};

// ODBG_Plugindata() is a "must" for valid OllyDbg plugin. It must fill in
// plugin name and return version of plugin interface. If function is absent,
// or version is not compatible, plugin will be not installed. Short name
// identifies it in the Plugins menu. This name is max. 31 alphanumerical
// characters or spaces + terminating '\0' long. To keep life easy for users,
// this name should be descriptive and correlate with the name of DLL.
extc int _export cdecl ODBG_Plugindata(char shortname[32]) {
  strcpy(shortname, "OllyStepNSearch");       // Name of plugin
  return PLUGIN_VERSION;
};

// OllyDbg calls this obligatory function once during startup. Place all
// one-time initializations here. If all resources are successfully allocated,
// function must return 0. On error, it must free partially allocated resources
// and return -1, in this case plugin will be removed. Parameter ollydbgversion
// is the version of OllyDbg, use it to assure that it is compatible with your
// plugin; hw is the handle of main OllyDbg window, keep it if necessary.
// Parameter features is reserved for future extentions, do not use it.
extc int _export cdecl ODBG_Plugininit(int ollydbgversion,HWND hw,ulong *features) {
  // This plugin uses all the newest features, check that version of OllyDbg is
  // correct. I will try to keep backward compatibility at least to v1.99.
  if (ollydbgversion<PLUGIN_VERSION)
    return -1;
  // Keep handle of main OllyDbg window. This handle is necessary, for example,
  // to display message box.
  hwMain=hw;
  // Plugin successfully initialized. Now is the best time to report this fact
  // to the log window. To conform OllyDbg look and feel, please use two lines.
  // The first, in black, should describe plugin, the second, gray and indented
  // by two characters, bears copyright notice.
  Addtolist(0, 0, "OllyStepNSearch %s", szVersion);
  Addtolist(0, -1, "  Public domain, no Copyright 2006 Didier Stevens http://DidierStevens.com");
	iFlagRegPrevNotInitialized = 1;
	iFlagEnableStepSearch = 0;

	LoadFromOllyDbgIni();

  return 0;
};

// Function adds items either to main OllyDbg menu (origin=PM_MAIN) or to popup
// menu in one of standard OllyDbg windows. When plugin wants to add own menu
// items, it gathers menu pattern in data and returns 1, otherwise it must
// return 0. Except for static main menu, plugin must not add inactive items.
// Item indices must range in 0..63. Duplicated indices are explicitly allowed.
extc int _export cdecl ODBG_Pluginmenu(int origin,char data[4096],void *item) {
  switch (origin) {
    // Menu creation is very simple. You just fill in data with menu pattern.
    // Some examples:
    // 0 Aaa,2 Bbb|3 Ccc|,,  - linear menu with 3items, relative IDs 0, 2 and 3,
    //                         separator between second and third item, last
    //                         separator and commas are ignored;
    // #A{0Aaa,B{1Bbb|2Ccc}} - unconditional separator, followed by popup menu
    //                         A with two elements, second is popup with two
    //                         elements and separator inbetween.
    case PM_MAIN:                      // Plugin menu in main window
      strcpy(data, "0 &Toggle StepNSearch");
      strcat(data, ",1 &Break on string");
      strcat(data, ",|2 &Help");
      strcat(data, ",3 &About");
      // If your plugin is more than trivial, I also recommend to include Help.
      return 1;
    default: break;                    // Any other window
  };
  return 0;                            // Window not supported by plugin
};

// This optional function receives commands from plugin menu in window of type
// origin. Argument action is menu identifier from ODBG_Pluginmenu(). If user
// activates automatically created entry in main menu, action is 0.
extc void _export cdecl ODBG_Pluginaction(int origin,int action,void *item) {
  char achBuf[1024];
  char achCmd[1024];
  
  if (origin==PM_MAIN) {
    switch (action) {
      case 0:
      	iFlagEnableStepSearch = iFlagEnableStepSearch ? 0 : 1;
      	Flash("OllyStepNSearch is %s", iFlagEnableStepSearch ? "enabled" : "disabled");
				break;

      case 1:
      	strcpy(achBuf, achSearchText);
      	if (Gettext("Enter string to break on, empty = no break", achBuf, 0, NM_REFTXT, FIXEDFONT) > -1)
      		if (strcmp(achBuf, achSearchText))
      		{
		      	strcpy(achSearchText, achBuf);
						iFlagSearchForSearchText = strcmp(achSearchText, "") == 1;
						Pluginwritestringtoini(hiDLL, INI_VERSION, szVersion);
						Pluginwritestringtoini(hiDLL, INI_SEARCH, achSearchText);
      		}
				break;

      case 2:
				GetModuleFileName(hiDLL, achBuf, 1024);
				strcpy(achBuf + strlen(achBuf) - 3, "txt");
				sprintf(achCmd, "\"%s\"", achBuf);
			  system(achCmd);	
				break;

      case 3:
      	sprintf(achBuf, "OllyStepNSearch %s plugin v1.10\nPublic domain, no Copyright 2006 Didier Stevens\nhttp://DidierStevens.com", szVersion);
        MessageBox(hwMain, achBuf, "OllyStepNSearch plugin", MB_OK|MB_ICONINFORMATION);
        break;
      default: break;
    }; 
	}
};

// Function is called when user opens new or restarts current application.
// Plugin should reset internal variables and data structures to initial state.
extc void _export cdecl ODBG_Pluginreset(void) {
	iFlagRegPrevNotInitialized = 1;
	iFlagEnableStepSearch = 0;
	LoadFromOllyDbgIni();
};

// OllyDbg calls this optional function when user wants to terminate OllyDbg.
// All MDI windows created by plugins still exist. Function must return 0 if
// it is safe to terminate. Any non-zero return will stop closing sequence. Do
// not misuse this possibility! Always inform user about the reasons why
// termination is not good and ask for his decision!
extc int _export cdecl ODBG_Pluginclose(void) {
  return 0;
};

// OllyDbg calls this optional function once on exit. At this moment, all MDI
// windows created by plugin are already destroyed (and received WM_DESTROY
// messages). Function must free all internally allocated resources, like
// window classes, files, memory and so on.
extc void _export cdecl ODBG_Plugindestroy(void) {
};

// Called after a step
int ODBG_Pausedex(int reason, int extdata, t_reg *reg, DEBUG_EVENT *debugevent)
{
	int iLen;
	int iIter;
	t_disasm da;
	int iFound;
	char achText[TEXTLEN];
	unsigned char achInstStr[MAXCMDSIZE];

	// Do nothing if the plugin is not enabled
  if (iFlagEnableStepSearch == 0)
  	return 0;

	if (reg == NULL)
		return 0;

	// Initialize
	if (iFlagRegPrevNotInitialized == 1)
	{
		iFlagRegPrevNotInitialized = 0;
		for (iIter = 0; iIter < 8; iIter++)
			ulRegPrev[iIter] = reg->r[iIter];
	}

	// Step Over if we are above the limit address,
	// normally we should break here, but it happens
	// Just continue
	if (reg->ip >= ulStepInLimit)
	{
		iStep = STEP_OVER;
		Go(0, 0, iStep, 1, 1);
		return 0;
	}

	// Check if registers have changed, if yes if they point to a string, and if the string contains the search text
	iFound = 0;
	if (iStep == STEP_IN)
		for (iIter = 0; iIter < 8; iIter++)
		{
			if (ulRegPrev[iIter] != reg->r[iIter])
			{
				if (iIter != 4 && Decodeascii(reg->r[iIter], achText, TEXTLEN, DASC_NOHEX) != 0)
				{
		   		Addtolist(reg->ip, 0, "OllyStepNSearch: %s %08lX -> %08lX string %s", aszRegName[iIter], ulRegPrev[iIter], reg->r[iIter], achText);
		   		if (iFlagSearchForSearchText && strstr(achText, achSearchText) != NULL)
		   			iFound = 1;
		   	}
				ulRegPrev[iIter] = reg->r[iIter];
			}
		}
	// Break if we find the search text
	if (iFound == 1)
	{
		Infoline ("Found %s", achSearchText);
		return 0;
	}

	// Analyze the next command to decide if we Step In of Step Over
	// Analysis is needed because I didn't find out how to read OllyDbgs t_disasm data
	iStep = STEP_IN;
	iLen = Readcommand(reg->ip, (char *) achInstStr);
	if (iLen == 0)
		return 0;

	Disasm(achInstStr, MAXCMDSIZE, reg->ip, NULL, &da, DISASM_ALL, Getcputhreadid()); 
	switch (da.cmdtype)
	{
		case C_CAL:
		case C_JMP:
		case C_JMC:
			if (da.jmpaddr >= ulStepInLimit)
				iStep = STEP_OVER;
			else if (Followcall(da.jmpaddr) >= ulStepInLimit)
				iStep = STEP_OVER;
			break;
			
		case C_REP:
			iStep = STEP_OVER;
	}
	
	Go(0, 0, iStep, 1, 1);
	
	return 0;
}
