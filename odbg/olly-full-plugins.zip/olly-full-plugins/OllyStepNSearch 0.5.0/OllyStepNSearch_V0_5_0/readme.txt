Installation:
Copy OllyStepNSearch.dll and OllyStepNSearch.txt in the OllyDbg plugin directory

Help:
Read OllyStepNSearch.txt