#define IDD_OPTIONS                     100
#define IDC_CHK_ENABLE									101
#define IDC_EDT_SEARCHSTRING            102
#define IDC_CHK_SEARCHLOG               103
#define IDC_EDT_STEPINLIMIT             104
#define IDC_CHK_DISABLEAFTERBREAK       105
#define IDC_CHK_REGISTERS       				106
#define IDC_CHK_INFORMATION			      	107

#define IDD_HELP                     		200
#define IDC_EDT_HELP                    201
