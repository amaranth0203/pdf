Installation:
Copy OllyStepNSearch.dll in the OllyDbg plugin directory
