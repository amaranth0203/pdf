-------------------------------
OllyPad plugin v1.0 by SHaG
-------------------------------

1. About OllyPad
2. Status
3. Contact me
4. License and source code
5. Thanks!

------------------------------

1. About OllyPad
-------------------
OllyPad is a plugin for OllyDbg, which is, in my opinion, 
the best application-mode debugger out there. OllyPad lets
you create notes for the currently debugged application
and stores them for later use. Next time you open the
application in OllyDbg your notes along with OllyPad window
size and placement will be restored.
Press ALT-F11 to show the plugin window and ALT to hide it 
(this functionality is coded by The Kluger).

------------------------------

2. Status (10 June 2004)
----------------------------
This is the first release of this plugin. I don't think I
will develop it much more - I'm quite busy as it is, and I
also have OllyScript to care about.

------------------------------

3. Contact me
-------------
To contact me you can post your question in the forum or go on IRC 
and message SHaG on EFnet. You can also mail me to shag-at-apsvans-dot-com.

------------------------------

4. License and source code
--------------------------
You are free to use this plugin and the source code however 
you see fit. However please name me in your documentation/about box and if 
the project you need my code for is on a larger scale please also notify 
me - I am curious.

Source code for this plugin is included in the distribution archive.

------------------------------

5. Thanks
--------------------------
Thanks to The Kluger for modifying the plugin by adding menu shortcut,
background colour and hide on ALT.