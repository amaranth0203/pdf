Hash Sniffer 2.0 Ollydbg 1.10 Plugin

***
Version 2.0 4th September 2007

Hash Sniffer is a hashing tool useful for analysing app crypto routines. Use it to do test hashes on app data, strings or files.

version 2.0 supports most common hash algorithms.

*** 
Use

Install in the Olly Plugins Folder

1) Select data to be hashed in Ollydbg dump or memory window

2) Right click and select "Hash Sniffer"

Help info is included in the plugin.

***

Ziggy

September 2007
