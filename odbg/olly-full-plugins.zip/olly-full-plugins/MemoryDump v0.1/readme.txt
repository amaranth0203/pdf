I often need copy just a number of bytes from debugged process to a file, there are few plugins but all of them works on principle of entering start and end addresses manually. I've been searching for something simple which would allowed me easily copy a number of bytes from dump window but could not find anything, so I decided to write it myself.

Simply select desired bytes in dump window, open right click menu and pick 'Memory Dump' to save them.

- copy to clipboard: this comes handy when user wants to access string from dump fast and use it immediately somewhere else (does not work very well with control characters)

- version for immunity debugger