Here is a small plugin for OllyDbg 1.10 which allow you to replace the old disassemble routine used in OllyDbg by a more recent one (beaengine). With this plugin, you can now debug MMX, FPU, SSE, SSE2, SSE3 and SSSE3 without problems.

Example :

Code:
00401000  PSLLQ MM0,QWORD PTR DS:[402020]
00401007  MOVQ MM0,QWORD PTR DS:[402020]
0040100E  MOV EAX,1235
00401013  MOV DWORD PTR DS:[402028],EAX
00401018  ???                                      ; Unknown command
0040101A  ADD EAX,SSE.00402028
0040101F  ???                                      ; Unknown command
00401021  ADD EAX,SSE.00402028
00401026  ???                                      ; Unknown command
00401028  ADD EAX,SSE.00402028
0040102D  MOVQ QWORD PTR DS:[402020],MM0
00401034  MOV EDI,SSE.00402000
00401039  MOVHPS XMM5,QWORD PTR DS:[EDI+8]
0040103D  MOVLPS XMM5,QWORD PTR DS:[EDI]
00401040  ???                                      ; Unknown command
00401042  IN EAX,DX                                ; I/O command
00401043  MOV ESI,SSE.00402010
00401048  MOVUPS XMM1,DQWORD PTR DS:[ESI]
0040104B  ???                                      ; Unknown command
0040104D  LEAVE
0040104E  MULPS XMM1,XMM5
00401051  ???                                      ; Unknown command
00401054  LEAVE
00401055  SUB ESP,10
00401058  MOVHPS QWORD PTR SS:[ESP],XMM1
0040105C  MOVLPS QWORD PTR SS:[ESP+8],XMM1


With FullDisasm : (press Ctrl+W or Ctrl+X for local action) :

Code:
00401000  psllq mm0, qword ptr [402020h]
00401007  movq mm0, qword ptr [402020h]
0040100E  mov eax, 1235h
00401013  mov dword ptr [402028h], eax
00401018  paddq mm0, qword ptr [402028h]           ; Unknown command
0040101F  psubq mm0, qword ptr [402028h]           ; Unknown command
00401026  pmuludq mm0, qword ptr [402028h]         ; Unknown command
0040102D  movq qword ptr [402020h], mm0
00401034  mov edi, 402000h
00401039  movhps xmm5, qword ptr [edi+8h]
0040103D  movlps xmm5, qword ptr [edi]
00401040  cvtdq2ps xmm5, xmm5                      ; Unknown command
00401043  mov esi, 402010h
00401048  movups xmm1, dqword ptr [esi]
0040104B  cvtdq2ps xmm1, xmm1                      ; Unknown command
0040104E  mulps xmm1, xmm5
00401051  cvtps2dq xmm1, xmm1                      ; Unknown command
00401055  sub esp, 10h
00401058  movhps qword ptr [esp], xmm1
0040105C  movlps qword ptr [esp+8h], xmm1

http://binary-reverser.org
