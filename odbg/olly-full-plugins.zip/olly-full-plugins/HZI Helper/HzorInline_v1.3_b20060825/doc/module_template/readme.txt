A template in FASM v1.64 syntax for module developpers.
Download FASM from http://flatassembler.net.
If you transform this to other language please send it to me.
