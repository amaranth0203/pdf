This plugin is a general purpose plugin for OllyDbg that fixes some annoying things of Olly / bugs of Olly v1.10.

version 1.12
- fixed a problem that could occur with some plugins on exit (olly crash)

version 1.11
- bugfix: some options could fail if Olly was launched from context-menu or when attaching.

version 1.1
- anti-anti-debug added (Against anti-attach tricks)
- added follow in disassembler for packed apps
- Advanced CTRL+G
- added WinUPack patch
- plugin-limitation patch now supports patched olly (Shadow, etc)
- added CRC-ignore option (so you don't have to reanalyze file on modification, this keeps UDD and all BPs, patches, etc)
- added ignore modified BP, so olly doesn't disable BPs if memory is modified there

version 1.02
- supports now to patch plugin-limit of 32 up to 147 plugins (i guess so much are not available atm :-) if you have so much, i can simply expand the limitation lol)

version 1.01
- fixed for re-pair patched OllyDbgs

version 1.0
- Fixed analysis for a wrong value of NumOfRvaAndSizes.
- added options in plugins-menu
- fixes "%s%s" bug now also for files with "%s" in it. Olly can now also output debug-strings with "%s%s" in it and all other types of "%s%s".
- fixes a bug of olly (crashes for a faked imagebase on object-files scanning)
- added option to skip "Entry point alert"
- added option to skip "Too many patches"
- option for dll-handling

current limitations:
- dll-loading message isn't skipped when launching from context (because plugins aren't loaded then)