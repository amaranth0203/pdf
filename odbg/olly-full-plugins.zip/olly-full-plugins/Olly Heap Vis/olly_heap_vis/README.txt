For general information see

    Documentation\README.txt
