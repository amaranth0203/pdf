=============================
 Exception Counter v0.1 beta
=============================
        25 August 2006
=============================

What is it?
-----------
  This is a plugin for Olly to automate the 
process of unpacking with exceptions.
(The way which we count the number of exceptions
before the app runs and then we pass exceptions 
n-1 times in next restart)

How to use it?
--------------
Simple :P

1) Uncheck necessary exception ticks in Exceptions
   tab of Olly Options (in Debugging Options).
2) Run Level 1 of plugin ("Start Counting").
3) Once the program loaded completely, start level 2
   of plugin ("Bring me to OEP").
4) Set a memory breakpoint on code section of program
   (Do it from Memory map window)
5) Press Shift+F9 for the last time to go to OEP :)

Good Luck! 

--------------------------------
ZeetreX
bug/report: smbl64@yahoo.com
--------------------------------